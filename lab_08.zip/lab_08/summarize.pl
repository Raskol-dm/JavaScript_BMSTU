ok.
sum(S1,A,B,C):- S1 > 0,write(S1).
sum(S1,A,B,C):- S2 is (A + B + C), sum(S2,A,B,C).

input(A,B,C):-read(A),read(B),read(C);ok.
f :-input(A,B,C),sum(0,A,B,C),ok.
