ok.
pow(C1,S1,A,B,C):- C1 > B,write(S1).
pow(C1,S1,A,B,C):- C1 < A, C2 is (C1+1), pow(C2,S1,A,B,C).
pow(C1,S1,A,B,C):- C1 mod C =:=0,write(C1),nl,C2 is C1+1,S2 is (S1+C1),pow(C2,S2,A,B,C);
C2 is C1+1, pow(C2,S1,A,B,C).

input(A,B,C):-read(A),read(B),read(C);ok.
f :-input(A,B,C),pow(0,0,A,B,C),ok.
