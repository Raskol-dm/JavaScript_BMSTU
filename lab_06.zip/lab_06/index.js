
"use strict";

// импорт библиотеки
const express = require("express");

// запускаем сервер
const app = express();
const port = 5000;
app.listen(port);
console.log(`Server on port ${port}`);

// активируем шаблонизатор
app.set("view engine", "hbs");

// заголовки в ответ клиенту
app.use(function(req, res, next) {
    res.header("Cache-Control", "no-cache, no-store, must-revalidate");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Origin", "*");
    next();
});

const games_con = [
    { a: "The Witcher 3", b: "Выживание", c: "18" },
    { a: "GTA V", b: "Role Play", c: "16" },
    { a: "Свинка Пепа", b: "Убить свина", c: "24" },
    { a: "Sourth Park", b: "Прохождение", c: "18" },
    { a: "Лунтик", b: "Без понятия", c: "6" },
    { a: "Need for Speed", b: "Гонки", c: "14" }
];


// выдача страницы с массивом учеников
app.get("/page/games", function(request, response) {
    const infoObject = {
        descriptionValue: "Компуктер геймс",
        games_mas: [
            {a: "The Witcher 3", b: "Выживание", c: "18"},
            {a: "GTA V", b: "Role Play", c: "16"},
            {a: "Свинка Пепа", b: "Убить свина", c: "24"},
            { a: "Sourth Park", b: "Прохождение", c: "18" },
            {a: "Лунтик", b: "Без понятия", c: "6" },
            {a: "Need for Speed", b: "Гонки", c: "14"}
        ]
    };
    response.render("games.hbs", infoObject);
});

app.get("/page/games/:age", function(request, response) {
    let games_mas = [];
    console.log(request.params.age);
    for (let i = 0; i < games_con.length; i++) {
        if (parseInt(games_con[i].c) <= parseInt(request.params.age))
        games_mas.push(games_con[i])
    }

    console.log(games_mas);

    const infoObject = {
        descriptionValue: "Компуктер геймс",
        games_mas
    };
    response.render("games.hbs", infoObject);
});
    