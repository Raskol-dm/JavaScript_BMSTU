"use strict";

// импортируем библиотеку
const express = require("express");
const fs = require("fs");
const { type } = require("os");


// запускаем сервер
const app = express();
const port = 5000;
app.listen(port);
console.log(`Server on port ${port} \n\n`);

// отправка статических файлов
const way = __dirname + "/static";
app.use(express.static(way));

// заголовки в ответ клиенту
app.use(function(req, res, next) {
    res.header("Cache-Control", "no-cache, no-store, must-revalidate");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Origin", "*");
    next();
});


// body
function loadBody(request, callback) {
    let body = [];
    request.on('data', (chunk) => {
        body.push(chunk);
    }).on('end', () => {
        body = Buffer.concat(body).toString();
        callback(body);
    });
}

// it is post
app.post("/save/info", function(request, response) {
    loadBody(request, function (body) {
        let putmatr = "[";
        const obj = JSON.parse(body);
        const a = obj["a"];
        const b = obj["b"];
        const c = obj["c"];
        const contentString = `[\"${a}\",\"${b}\",\"${c}\"],`;
        if (fs.existsSync("file.txt")) {
            console.log(typeof (a));
            console.log(a);
            console.log(typeof (c) + ": " + c);
            let arr = fs.readFileSync("file.txt", "utf8");
            console.log(typeof (arr));
            console.log(arr);
            arr = arr.slice(0,-1);
            console.log(arr);
            putmatr += arr + "]";
            console.log(putmatr);
            const matr = JSON.parse(putmatr);
            console.log(matr);
            let flag = true;
            for (let i = 0; i < matr.length; i++)
            {
                console.log(matr[i]);
                if ((a === matr[i][0]) || (c === matr[i][2]))
                // Уточнить И то и то или Нет???
                {
                    console.log("Includes in file");
                    response.end(JSON.stringify({
                    result: "Don't save, simple date"
                    }));
                    flag = false;
                }
            }
            if (flag) {
                fs.appendFileSync("file.txt", contentString);
                response.end(JSON.stringify({
                result: "Save content ok"
                }));
            }
        } else {
            fs.appendFileSync("file.txt", contentString);
            response.end(JSON.stringify({
            result: "Save content ok"
            }));
        }
        
    });
});


// выдать страницу
app.get("/page", function(request, response) {
    response.sendFile(__dirname + "/" + "page.html");
});


// выдать запись
app.get("/record", function(request, response) {
    console.log(request.url);
    const key = request.query.k;
    let putmatr = "[";
    let arr = fs.readFileSync("file.txt", "utf8");
    arr = arr.slice(0,-1);
    putmatr += arr + "]";
    console.log(putmatr);
    const matr = JSON.parse(putmatr);
    console.log(matr);
    let flag = -1;
    for (let i = 0; i < matr.length; i++)
    {
        if ((key === matr[i][0]))
        {
            flag = i;
        }
    }
    if (flag > -1) {
        console.log(`Email: ${matr[flag][0]}`);
        console.log(`LastName: ${matr[flag][1]}`);
        console.log(`Phone: ${matr[flag][2]}`);
        response.end(JSON.stringify({
            Em: key,
            Ln: matr[flag][1],
            Ph: matr[flag][2]
        }));
    } else {
        response.end(JSON.stringify({
              Em: null,
            Ln: null,
            Ph: null
        }));
    }
});