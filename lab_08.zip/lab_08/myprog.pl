cleverboy(X):- clever(X), boy(X).
clevergirl(X):- clever(X), girl(X).
boy(maxim).
boy(george).
girl(nina).
girl(ann).
clever(maxim).
clever(nina).