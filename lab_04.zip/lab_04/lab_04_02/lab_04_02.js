"use strict";

const arr = [];
const fs = require("fs");

const express = require("express");

const app = express();
const port = 5015;
app.listen(port);
console.log("My server on port " + port);

app.get("/me/page", function(request, response) {
    const nameString = request.query.p;
    if (fs.existsSync(nameString)) {
        const contentString = fs.readFileSync(nameString, "utf8");
        response.end(contentString);
    } else {
        const contentString = fs.readFileSync("bad.html", "utf8");
        response.end(contentString);
    }
});

app.get("/index/mas", function(request, response) {
    const a = request.query.a;
    const nameString = "as.txt";
    let MyStrPs = undefined;
    if (fs.existsSync(nameString)) {
        console.log("File exists");
        const MyStr = fs.readFileSync(nameString, "utf-8");
        MyStrPs = JSON.parse(MyStr);
    } else {
        console.log("File was not found");
        const contentString = fs.readFileSync("bad.html", "utf8");
        response.end(contentString);
    }


    const aInt = parseInt(a);

    if (aInt > (MyStrPs.length - 1)) {
        const contentString = fs.readFileSync("bad.html", "utf8");
        response.end(contentString);
    } else {
        console.log(MyStrPs[a]);
        const answerJSON = JSON.stringify({result: MyStrPs[a]});
        response.end(answerJSON);
    }
});