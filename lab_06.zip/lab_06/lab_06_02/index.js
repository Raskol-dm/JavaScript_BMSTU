"use strict"

let globint = -1;

const clients = [
    { log: "papa", pass: "papa", hobby: "box", age: 16},
    { log: "rasco", pass: "123456", hobby: "action", age: 19 },
    { log: "qwerty", pass: "qazwsx", hobby: "gaming", age: 34 },
    { log: "mama", pass: "mama", hobby: "cooking", age: 32 },
    { log: "twitchkilo", pass: "killer228", hobby: "hacking", age: 12 },
    { log: "Msprosto", pass: "qwerty", hobby: "music", age: 23 },
];


// импорт библиотеки
const express = require("express");
const fs = require("fs");

const cookieSession = require("cookie-session");

// запускаем сервер
const app = express();
const port = 5000;
app.listen(port);
console.log(`Server on port ${port}`);

// заголовки в ответ клиенту
app.use(function(req, res, next) {
    res.header("Cache-Control", "no-cache, no-store, must-revalidate");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Origin", "*");
    next();
});

app.use(cookieSession({
    name: 'session',
    keys: ['hhh', 'qqq', 'vvv'],
  
    // Cookie Options
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }))

app.get("/login", function(request, response) {
    const nameString = "exit.html";
    if (fs.existsSync(nameString)) {
        const contentString = fs.readFileSync(nameString, "utf8");
        response.end(contentString);
    } else {
        const contentString = fs.readFileSync("bad.html", "utf8");
        response.end(contentString);
    }
});

app.get("/account", function(request, response) {
    if(!request.session.login) return response.redirect("/login")
    if(!request.session.password) return response.redirect("/login")

    if (globint == -1) {
        response.redirect("/login");
    }
    let username = request.session.login
    let age = clients[globint].age
    let hobby = clients[globint].hobby

    const infoObject = {
        descriptionValue: "Details",
        username,
        age,
        hobby
    };
    response.render("account.hbs", infoObject);
});

app.get("/login_process", function (request, response) {
    // получаем параметры запроса
    let flag = false;
    globint = -1;
    const login = request.query.login;
    const password = request.query.password;
    for (let i = 0; i < clients.length; i++) {
        if (clients[i].log === login) {
            if (clients[i].pass === password) {
                console.log(clients[i].log);
                console.log(clients[i].pass);
                request.session.login = login;
                request.session.password = password;
                console.log(request.session.login);
                globint = i;
                flag = true;
                response.redirect("/account");
            } else {
                response.end("Wrong Password");
            }
        }
    }
    if (!flag) {
        response.end("Not registered");
    }
});

app.get("/logout", function(request, response) {
    request.session = null;
    response.redirect("/login")
});