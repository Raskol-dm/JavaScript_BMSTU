ok.
fib(X,Y,A, B):- X > B.
fib(X, Y, A, B):- X < A, Z is X + Y, fib(Y, Z, A, B).
fib(X, Y, A, B):- write(X), nl, Z is X + Y, fib(Y, Z, A, B).
input(A, B) :- read(A), read(B); ok.
func :- input(A, B), fib(0, 1, A, B), ok.





