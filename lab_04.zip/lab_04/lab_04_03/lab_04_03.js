"use strict";

const arr = [];
const fs = require("fs");
const nameString = "as3.txt";
const nameHtmlFile = "aindex.html";

function makeHTMLcode(requirestms) {
  let container =
        "<!DOCTYPE html>\n" +
        "<html>\n" +
        "<head>\n" +
        "    <meta charset=" + "UTF-8" + ">\n" +
        "    <title>Practicale</title>\n" +
        "</head>\n" +
        "\n" + 
        "<body>\n" +
        "     <h1>Practicale</h1>\n" +
        "     <form method =\"GET\" action=\"" + requirestms[0] + "\">\n";
  for (let i = 1; i < requirestms.length; i++)
  {
    container +=
        "         <p>" + requirestms[i] + "</p>\n" +
        "         <input name=\"" + requirestms[i] + "\" spellcheck=\"false\" autocomplete=\"off\">\n";
  }
  container +=
        "         <br>\n" +
        "         <br>\n" +
        "         <input type=\"submit\" value=\"Отправить запрос\">\n" +
        "      </form>\n" +
        "</body>\n" +
        "\n" + 
        "</html>\n";
  
  
  fs.writeFileSync(nameHtmlFile, container);
}
if (fs.existsSync(nameString)) {

    console.log("File exists");
    const String = fs.readFileSync(nameString, "utf-8");
    const MyStr = JSON.parse(String);
  console.log(MyStr);
  makeHTMLcode(MyStr);

} else {
  console.log("File was not found");
}
