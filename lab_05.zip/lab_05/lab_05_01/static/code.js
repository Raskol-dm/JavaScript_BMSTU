"use strict";

window.onload = function() {
    // input fields
    const f1 = document.getElementById("email");
    const f2 = document.getElementById("secondname");
    const f3 = document.getElementById("phone");

    // button
    const btn = document.getElementById("send-info");

    // label
    const label = document.getElementById("result-label");

    //ajax post
    function ajaxPost(urlString, bodyString, callback) {
        let r = new XMLHttpRequest();
        r.open("POST", urlString, true);
        r.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        r.send(bodyString);
        r.onload = function() {
            callback(r.response);
        }
    }

    // click event
    btn.onclick = function() {
        const a = f1.value;
        const b = f2.value;
        const c = f3.value;
        ajaxPost("/save/info", JSON.stringify({
            a, b, c
        }), function(answerString) {
            const answerObject = JSON.parse(answerString);
            const result = answerObject.result;
            alert(result);
        });
    };
};