"use strict";

// импортируем необходимые библиотеки
const express = require("express");
const fs = require("fs");
const { type } = require("os");

// запускаем сервер
const app = express();
const port = 5000;
app.listen(port);
console.log(`Server on port ${port}`);

// отправка статических файлов
const way = __dirname + "/static";
app.use(express.static(way));

// заголовки в ответ клиенту
app.use(function(req, res, next) {
    res.header("Cache-Control", "no-cache, no-store, must-revalidate");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Origin", "*");
    next();
});


// body
function loadBody(request, callback) {
    let body = [];
    request.on('data', (chunk) => {
        body.push(chunk);
    }).on('end', () => {
        body = Buffer.concat(body).toString();
        callback(body);
    });
}

// it is post
app.post("/save/info", function(request, response) {
    loadBody(request, function (body) {
        let putmatr = "[";
        const obj = JSON.parse(body);
        const a = obj["a"];
        const b = obj["b"];
        const c = obj["c"];
        const contentString = `[\"${a}\",\"${b}\",\"${c}\"],`;
        if (fs.existsSync("file.txt")) {
            console.log(typeof (a));
            console.log(a);
            console.log(typeof (c) + ": " + c);
            let arr = fs.readFileSync("file.txt", "utf8");
            console.log(typeof (arr));
            console.log(arr);
            arr = arr.slice(0,-1);
            console.log(arr);
            putmatr += arr + "]";
            console.log(putmatr);
            const matr = JSON.parse(putmatr);
            console.log(matr);
            let flag = true;
            for (let i = 0; i < matr.length; i++)
            {
                console.log(matr[i]);
                if ((a === matr[i][0]) || (c === matr[i][2]))
                {
                    console.log("Includes in file");
                    response.end(JSON.stringify({
                    result: "Don't save, simple date"
                    }));
                    flag = false;
                }
            }
            if (flag) {
                fs.appendFileSync("file.txt", contentString);
                response.end(JSON.stringify({
                result: "Save content ok"
                }));
            }
        } else {
            fs.appendFileSync("file.txt", contentString);
            response.end(JSON.stringify({
            result: "Save content ok"
            }));
        }
        
    });
});