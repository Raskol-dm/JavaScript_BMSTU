"use strict";

const fs = require("fs");

const express = require("express");

const app = express();
const port = 5015;
app.listen(port);
console.log("My server on port " + port);

app.get("/me/page", function(request, response) {
    const nameString = request.query.p;
    if (fs.existsSync(nameString)) {
        const contentString = fs.readFileSync(nameString, "utf8");
        response.end(contentString);
    } else {
        const contentString = fs.readFileSync("bad.html", "utf8");
        response.end(contentString);
    }
});
let arr = [];
app.get("/calculate/sum", function(request, response) {
    const a = request.query.a;
    const b = request.query.b;
    const c = request.query.c;
  const ai = parseInt(a);
  const bi = parseInt(b);
  const ci = parseInt(c);
  if (ai > bi) {
      const contentString = fs.readFileSync("bad.html", "utf8");
        response.end(contentString);
  } else {
    for (let i = ai; i <= bi; i++){
      if (i % ci === 0) {
        arr.push(i);
      }
    }
    console.log(arr);
    const answerJSON = JSON.stringify({result: arr});
    response.end(answerJSON);
  }
});