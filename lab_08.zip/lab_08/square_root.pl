ok.
pow(X1,X2,X3,A,B):- X3 > B.
pow(X1,X2,X3,A,B):- X3 < A, X4 is X1 * X2, X5 = X1 + 1, pow(X5,X5,X4,A,B).
pow(X1,X2,X3,A,B):- write(X3),nl, X4 is X1 * X2, X5 = X1 + 1, pow(X5,X5,X4,A,B).
input(A,B):-read(A),read(B);ok.
f :-input(A,B),pow(0,0,0,A,B),ok.
